<?php

session_start();

$username = "";
$password = "";
$errors = "";

$db = mysql_connect('localhost','root','','examreg') or die("could not connect to database");

$username = mysql_real_escape_string($db, $_POST['username']);
$password = mysql_real_escape_string($db, $_POST['password']);

// if(empty($username)){array_push($errors, "Username is required")};
// if(empty($password)){array_push($errors, "Password is required")};

//check with same name
$user_check_query = "SELECT *from users where username = '$username' or password = '$password'";

$result = mysql_query($db, $user_check_query);
$users = mysql_fetch_assoc($result);

if($users){
	if($users['user_name'] === $username){array_push($errors, "Username is exists");}
}

//register if no error
if(count($errors)==0){
	$password = md5($password);
	$query = "INSERT INTO users(username, password) VALUES ('$username', '$password')";
	mysql_query($db, $query);
	$_SESSION['username'] = $username;
	$_SESSION['success'] = "You are now logged in";
	header('location: reg.php');
	
}

//login user
if(isset($_POST['login_user'])){
	$username = mysql_real_escape_string($db, $_POST['username']);
	$password = mysql_real_escape_string($db, $_POST['password']);

	if(empty($username)){
		array_push($errors, "Username is required");
	}
	if(empty($password)){
		array_push($errors, "Password is required");
	}

	if(count($errors) == 0){
		$password = md5($password);
		$query = "SELECT * FROM users WHERE username= '$username' AND password ='password'";
		$results =  mysql_query($db, $query);
		if(mysql_num_rows($results)){
			$_SESSION['username'] = $username;
			$_SESSION['success'] = "Logged in successfully";
			header('location: reg.php');
		}else{
			array_push($errors, "Wrong username/password");
		}
	}
}

 ?>