<?php 

	require "includes/dbh.inc.php";

	function getUsersData($id)
	{
		$array = array();
		$q = msqli_query("SELECT * FROM students WHERE studentid = ".$id);
		while ($r = mysqli_fetch_assoc($q)) {

						$array['studentid'] = $r['studentid'];
						$array['username'] = $r['username'];
						$array['password'] = $r['password'];
						$array['firstname'] = $r['firstname'];
						$array['lastname'] = $r['lastname'];
						$array['sex'] = $row['studentid'];
						$array['dateofbirth'] = $r['dateofbirth'];
						$array['mail'] = $r['mail'];

			# code...
		}
		return $array;
	}
function getId($username)
	{
		
		$q = msqli_query("SELECT studentid FROM students WHERE username = ".$username."'");
		while ($r = mysqli_fetch_assoc($q)) {
			return $r['studentid'];
		}
	}
	?>

 