<?php 
	require "header.php";

 ?>

<main>
	<div class="wrapper-main">
		<section class="section-default" style="margin-bottom: -5px">
			<h1 style="color: red; text-align: center;">SignUp</h1>
			<div style= "margin-left: 430px;">
			<form class="form-signup" action="includes/signup.inc.php" method="post">
				
				<input type="text" name="uid" placeholder="Username" style=" text-align: center;width: 300px;height: 41px;font-size: 17px;border: 3px solid green;background: #00dcffc4;">
				<br>
				<br>
				<input type="text" name="mail" placeholder="E-mail" style=" text-align: center;width: 300px;height: 41px;font-size: 17px;border: 3px solid green;background: #00dcffc4;">
				<br>
				<br>
				<input type="password" name="pwd" placeholder="Password" style=" text-align: center;width: 300px;height: 41px;font-size: 17px;border: 3px solid green;background: #00dcffc4;">
				<br>
				<br>
				<input type="password" name="pwd-repeat" placeholder="Repeat Password" style=" text-align: center;width: 300px;height: 41px;font-size: 17px;border: 3px solid green;background: #00dcffc4;">
				<br>
				<br>
				
			</form>
			<button type="submit" name="signup-submit" style= "margin-left: 112px;width: 81px;height: 36px;font-size: 17px;background: red;">SUBMIT</button>

			</div>
		</section>
	</div>
</main>


 <?php 
	require "footer.php";
	
 ?>