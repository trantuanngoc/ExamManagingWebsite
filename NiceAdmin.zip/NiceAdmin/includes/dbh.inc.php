<?php 

$servername = "localhost";
$dBUsername = "root";
$dBPassword = "";
$dBName = "webdata";

$conn = mysqli_connect($servername, $dBUsername,$dBPassword, $dBName);
if(!$conn){
	die("Connect failed: ".mysqli_connect_error());
}

?>
